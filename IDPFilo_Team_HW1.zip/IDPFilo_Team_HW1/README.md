# IDPFilo_Team_HW1
Welcome to our official bio of the IDPFilo Team!

## Hi! My name is Bernardo Macapagal.

I am an Interactive Media Design student here at Fanshawe College. I have a lot of hobbies in the creative field such as doing art and photography.

## Hey! My name is Bryle Flores.

This is a temporary text once again.